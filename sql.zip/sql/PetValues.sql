USE Animals;
INSERT INTO Pet VALUES
("Hamster", "Pet"),
("Dog", "Pet"),
("Cat", "Pet");