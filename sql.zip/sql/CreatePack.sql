USE Animals;
CREATE TABLE PackContent (ID int auto_increment, Name varchar(50) not null,
Type varchar(50), BirthDate date, Commands longtext, Gender varchar(10),
primary key (ID), foreign key (Type) REFERENCES PackAnimal (Species) 
ON DELETE RESTRICT ON UPDATE CASCADE, 
foreign key (Gender) REFERENCES GenderEnum (gender)
ON DELETE RESTRICT ON UPDATE CASCADE);
