INSERT INTO Animals.AnimalsEnum VALUES
 ('Pack Animal'),
 ('Pet');