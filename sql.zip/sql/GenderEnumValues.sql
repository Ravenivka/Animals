INSERT INTO Animals.GenderEnum Values 
('Male'),
('Female');