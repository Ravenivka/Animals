USE Animals;
INSERT INTO PackContent Values
(1,	'Fido',	'Dog',	'2020-01-01',	'Sit, Stay, Fetch', 'Female'),
(2,	'Whiskers',	'Cat',	'2019-05-15',	'Sit, Pounce', 'Male'),
(3,	'Hammy',	'Hamster',	'2021-03-10',	'Roll, Hide', 'Male'),
(4,	'Buddy',	'Dog',	'2018-12-10',	'Sit, Paw, Bark', 'Male'),
(5,	'Smudge',	'Cat',	'2020-02-20',	'Sit, Pounce, Scratch', 'Male'),
(6,	'Peanut',	'Hamster',	'2021-08-01',	'Roll, Spin', 'Female'),
(7,	'Bella',	'Dog',	'2019-11-11',	'Sit, Stay, Roll', 'Female'),
(8,	'Oliver',	'Cat',	'2020-06-30',	'Meow, Scratch, Jump', 'Female');
