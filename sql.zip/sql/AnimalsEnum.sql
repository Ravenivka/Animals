CREATE TABLE Animals.AnimalsEnum (animal varchar(50), primary key (animal));
CREATE TABLE Animals.GenderEnum (gender varchar(10), primary key (gender));
CREATE TABLE Animals.PackAnimal (Species varchar(50), primary key (Species), animal varchar(50), 
foreign key (animal) REFERENCES Animals.AnimalsEnum (animal)
ON DELETE RESTRICT ON UPDATE CASCADE);
CREATE TABLE Animals.Pet (Species varchar(50), primary key (Species), animal varchar(50), 
foreign key (animal) REFERENCES Animals.AnimalsEnum (animal)
ON DELETE RESTRICT ON UPDATE CASCADE);
