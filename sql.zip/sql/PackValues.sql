USE Animals;
INSERT INTO PackAnimal VALUES
("Donckey", "Pack Animal"),
("Horse", "Pack Animal"),
("Camel", "Pack Animal");